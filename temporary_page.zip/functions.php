<?php
function enqueue_tasty_catalog_styles() {
    wp_enqueue_style('tasty-catalog-style', get_template_directory_uri() . '/styles/style.css');
}

add_action('wp_enqueue_scripts', 'enqueue_tasty_catalog_styles');
