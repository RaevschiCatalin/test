<?php /* Template Name: Tasty Catalog Template */ ?>
<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo('charset'); ?>">
    <meta name="description" content="Descarcă catalogul gustos!">
    <meta name="keywords" content="descarcă, catalog, gustos, catalogul gustos, catalogul gustos descarcă">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="<?php echo get_stylesheet_uri(); ?>">
    <title><?php echo get_bloginfo('name'); ?></title>
    <?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
    <nav>
        <img class="tasty_logo" src="<?php echo get_template_directory_uri(); ?>/assets/images/logo%20tasty.png" alt="Tasty Logo">
        <img class="scandia_logo" src="<?php echo get_template_directory_uri(); ?>/assets/images/scandia%20logo.png" alt="Scandia Logo">
    </nav>
    <main>
        <div class="text">
            <p>Noi aducem savoare!</p>
            <h1>Direct din bucătăria noastră în farfuria ta,<span class="hilight">  pregătește-te pentru mesele delicioase la tine acasă.</span></h1>
        </div>
        <div class="download">
            <a href="<?php echo get_template_directory_uri(); ?>/assets/files/ScandiaFoodFROZEN_catalog.pdf" download>
                <div class="flex-container">
                    <p>Descarcă catalogul nostru delicios</p>
                    <img src="<?php echo get_template_directory_uri(); ?>/assets/images/Group%203.png" alt="Download the tasty catalogue">
                </div>
            </a>
        </div>
    </main>
    <?php wp_footer(); ?>
</body>
</html>
